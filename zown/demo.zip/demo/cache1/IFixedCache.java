package com.sf.hos.assistant.demo.cache1;

public interface IFixedCache<K,E>{
	public void put(K key,E value);
	
	public E get(K key);
	
	//是否已满
	public boolean isFull();
	
	public void remove(K key);
	
	public void remove();
	
	public int getLength();
}
