package com.sf.hos.assistant.demo.cache1;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class AbstractFixedCahce<K,E> implements IFixedCache<K,E>{
	private int MAX_LENGTH=0;  
	
	protected Map<K,ObjectHeat<E>> map=new ConcurrentHashMap<K,ObjectHeat<E>>();
	
	public AbstractFixedCahce(int length){
		this.map=new ConcurrentHashMap<K,ObjectHeat<E>>(length);
		this.MAX_LENGTH=length;
	}
	
	public synchronized int getLength(){
		return map.size();
	}
	
	public synchronized boolean isFull(){
		return map.size()>=this.MAX_LENGTH;
	}
	
	public synchronized void put(K key,E value){
		if(isFull()){
			remove();
		}
		ObjectHeat<E> objH=new ObjectHeat<E>();
		objH.setValue(value);
		map.put(key, objH);
			
	}
	
	public E get(K key){
		 map.get(key).getHeat().incrementAndGet();
		 return map.get(key).getValue();
	}
	
	@Override
	public void remove(K key) {
		map.remove(key);
		
	}
	
	static  class ObjectHeat<T> {
		//原值
		private T value;
		//热度
		private AtomicInteger heat=new AtomicInteger(0);
		public T getValue() {
			return value;
		}
		public void setValue(T value) {
			this.value = value;
		}
		public AtomicInteger getHeat() {
			return heat;
		}
		public void setHeat(AtomicInteger heat) {
			this.heat = heat;
		}
		
	}
}
