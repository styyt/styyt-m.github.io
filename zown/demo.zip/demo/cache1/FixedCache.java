package com.sf.hos.assistant.demo.cache1;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class FixedCache<K,V> extends AbstractFixedCahce<K,V>  implements IFixedCache<K,V>{

	public FixedCache(int length) {
		super(length);
	}

	{
		System.err.println("???????");
	}
	


	@Override
	public void remove() {
		Set<Map.Entry<K, ObjectHeat<V>>> values=map.entrySet();
		/*Collections.sort((List<ObjectHeat<V>>)values, new Comparator<ObjectHeat<V>>() {

			@Override
			public int compare(
					ObjectHeat<V> o1,
					ObjectHeat<V> o2) {
				return o2.getHeat().get()-o1.getHeat().get();
			}
		});*/
		K minKety=null;int minV=-1;
		for(Map.Entry<K, ObjectHeat<V>> item:values){
			int i=item.getValue().getHeat().get();
			//
			if(minV==-1){
				minV=i;
				minKety=item.getKey();
			}
			
			if(i<minV){
				minV=i;
				minKety=item.getKey();
			}
		}
		map.remove(minKety);
	}
	
	public static void main(String[] args) {
		FixedCache item=new FixedCache(4);
		item.put("my1", "my1");
		item.put("my2", "my2");
		item.put("my3", "my3");
		item.put("my4", "my4");
		item.get("my1");
		item.get("my2");
		item.get("my2");
		item.get("my2");
		item.get("my3");
		item.get("my3");
		item.put("my5", "my5");
		System.err.println("end");
		
		
	}
}
