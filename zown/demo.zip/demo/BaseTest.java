package com.sf.hos.assistant.demo;

public class BaseTest {
	public static void main(String[] args) {
		BaseTest ba=new BaseTest();
		ba.setName("11111");
		Integer i=100;
		String s="hello";
		ba.changeI(i);
		Character c='哈';
		System.err.println("i========="+i);
		System.err.println("s========="+s);
		System.err.println("ba========="+ba.getName());
		
		
		System.err.println(i.SIZE);
		System.err.println(c.SIZE);
		
		BaseInterface subject = new JDKDynamicProxy(new BaseInterfaceImpl()).getProxy();
        subject.doS();
        
        BaseInterfaceImpl cg=(BaseInterfaceImpl) new CGlibProxy().getInstance(new BaseInterfaceImpl());
        cg.doS();
	}
	
	public void changeI(Integer i){
		i=1000;
		System.err.println();
	}
	public void changeS(String s){
		s="hello word";
	}
	public void changeBa(BaseTest ba){
		ba=new BaseTest();
		ba.setName("123213");
	}
	
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
