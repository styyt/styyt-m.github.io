package com.sf.hos.assistant.demo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.junit.Assert;

public class ThreadTest {
	ReentrantLock lock = new ReentrantLock();  
	Condition condition = lock.newCondition();  
	public static void main(String[] args) throws InterruptedException {
		ThreadTest tt=new ThreadTest();
		String fileName="D://ttt.text";
		File f=new File(fileName);
		ReadThread r1=tt.new ReadThread("odd-1", 1, f);
		ReadThread r2=tt.new ReadThread("odd-2", 2, f);
		r1.setReadThread(r2);
		r2.setReadThread(r1);
		r1.start();
		r2.start();
		
		r1.join();
		r2.join();
		System.err.println("main end");
	}

	class ReadThread extends Thread{
		private String name;
		private Integer index;
		private File file;
		private ReadThread readThread;
		
		public ReadThread(String name,Integer i,File file) {
			this.name=name;
			this.index=i;
			this.file=file;
		}
		
		
		
		public ReadThread getReadThread() {
			return readThread;
		}
	
	
	
		public void setReadThread(ReadThread readThread) {
			this.readThread = readThread;
		}
	
	
	
		@Override
		public void run(){
			int readCount=0;
			Assert.assertNotNull(index);
			Assert.assertNotNull(name);
			StringBuilder sb = new StringBuilder();
			try {
				FileInputStream in=new FileInputStream(file);
				InputStreamReader read=new InputStreamReader(in);
				BufferedReader reader=new BufferedReader(read);
				String r;
				if((r=reader.readLine())!=null){
					sb.append(r);
				}
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String[] strs=sb.toString().split(";");
			for(String item:strs){
				try{
					lock.lock();
					Integer va=Integer.parseInt(item);
					if(readCount>0&& readCount%5==0){
//						condition
//						condition.await();
						try {
							readThread.join();
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}else{
						
						if(isOdd(this.index)){
							if(isOdd(va)){
								System.err.println(this.name+"----"+va);
								readCount++;
							}
						}else{
							if(!isOdd(va)){
								System.err.println(this.name+"----"+va);
								readCount++;
							}
						}
					}
					if(readCount>0 &&readCount%1000==0){
						System.err.println(this.name+"--ALL--"+readCount);
					}
				}catch(Exception e){
					e.printStackTrace();
				}finally{
					lock.unlock();
				}
				
			}
			
			System.err.println("end");
		}
		
		public boolean isOdd(int i){
			return !(i%2==0);
		}
	}
}