package com.sf.hos.assistant.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class WriteTest {
	public static void main(String[] args) throws IOException {
		File file =new File("D://ttt.text");
		if(!file.exists()){
			file.createNewFile();
		}
		StringBuilder sb=new StringBuilder();
		for(int i=0;i<1000000;i++){
			i=i+Math.round(10);
			sb.append(i);
			sb.append(";");
		}
		FileOutputStream o=new FileOutputStream(file);
		o.write(sb.toString().getBytes());
		o.close();
		System.err.println("end");
	}
}
