package com.sf.hos.assistant.demo;


public class KSTest {
	public static void main(String[] args) {
		int N=670;
		boolean b=true;
		if(N<0){
			b=false;
			N=N*-1;
		}
		int max=0;
		Integer[] fs=toArray(N);
        
		for(int i=0;i<fs.length;i++){
			Integer[] fsn=new Integer[fs.length+1];
			for(int j=0;j<fs.length;j++){
				if(i==j){
					
					fsn[j]=5;
				}else{
					fsn[j]=fs[j-1];
					
				}
				
			}
			
			int item=toInt(fsn);
			if(item>=max){
				max=item;
			}
		}
		if(!b){
			max=max*-1;
		}
		
		System.err.println(max);
        
        
        return;
	}
	
	public static  Integer[] toArray(int N){
		Integer num = N;// 输入的数字
		String str = num.toString();// 转化为字符串
		Integer[] intArray = new Integer[str.length()];// 新建一个数组用来保存num每一位的数字
		for (int i = 0; i < str.length(); i++) {
			// 遍历str将每一位数字添加如intArray
			Character ch = str.charAt(i);
			intArray[i] = Integer.parseInt(ch.toString());
		}
		for (int i = 0; i < intArray.length; i++) {
		// 遍历打印int[],察看运行结果.
			System.err.print(intArray[i] + " ");
		}
		return intArray;
	}
	
	public static int toInt(Integer[] intArray){
		String str=java.util.Arrays.toString(intArray);
		return Integer.parseInt(str);
	}
}
