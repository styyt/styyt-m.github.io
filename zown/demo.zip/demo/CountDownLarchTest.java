package com.sf.hos.assistant.demo;

import java.util.concurrent.CountDownLatch;

public class CountDownLarchTest {
	
	
	public static void main(String[] args) throws InterruptedException {
		Test2 tnew =new Test2();
		CountDownLatch cd=new CountDownLatch(2);
		tnew.setCd(cd);
		Runnable run1=new Runnable() {
			
			@Override
			public void run() {
				String name= Thread.currentThread().getName();
				for(int i=0;i<10;i++){
					System.err.println(name+"----"+i);
				}
				tnew.getCd().countDown();
				System.err.println(name+"----"+tnew.getCd().toString());
			}
		};
		
		Runnable run2=new Runnable() {
			
			@Override
			public void run() {
				String name= Thread.currentThread().getName();
				for(int i=0;i<10;i++){
					System.err.println(name+"----"+i);
				}
				tnew.getCd().countDown();
				System.err.println(name+"----"+tnew.getCd().toString());
			}
		};
		new Thread(run1).start();
		new Thread(run2).start();
		tnew.getCd().await();
		System.err.println("do main");
	}
}
class Test2{
	CountDownLatch  cd;

	public CountDownLatch getCd() {
		return cd;
	}

	public void setCd(CountDownLatch cd) {
		this.cd = cd;
	}
	
}