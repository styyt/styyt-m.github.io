package com.sf.hos.assistant.demo.nio;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.Scanner;

public class Client {
	private static final String host = "127.0.0.1";
    private static final int port = 8379;
    private Selector selector;
	public static void main(String[] args){
        InetSocketAddress address = new InetSocketAddress(host,port);
        ByteBuffer writeBytes=ByteBuffer.allocate(1024);
        Client client=new Client();
        SocketChannel sc =null;
        try{
            sc = SocketChannel.open();
            sc.configureBlocking(false);
            //第一次向selector注册链接事件
            client.selector = Selector.open();
            sc.register(client.selector, SelectionKey.OP_CONNECT);
            //链接服务端，触发OP_CONNECT事件
            sc.connect(address);
            while(true){
            	//监听所有key，没有key时间完成时会阻塞
            	int events = client.selector.select();
            	if(events>0){
            		Iterator<SelectionKey> selectionKeys = client.selector.selectedKeys().iterator();
            			while(selectionKeys.hasNext()){
            				 SelectionKey selectionKey = selectionKeys.next();
                             selectionKeys.remove();
                             SocketChannel socketChannel = (SocketChannel) selectionKey.channel();
                             //连接事件
                             if (selectionKey.isConnectable()) {
                            	 //获取key的socketChannel
                                 if (socketChannel.isConnectionPending()) {
                                	 //如果已经连接成功，则将状态改为链接完成，开始通讯
                                     socketChannel.finishConnect();
                                 }
                                 System.out.println("server connect success");
                                 //向selector注册read事件，当server write完毕触发
//                                 socketChannel.register(client.selector, SelectionKey.OP_READ);
//                                 
//                                 writeBytes.put(writeSomething());
//                                 writeBytes.flip();
//                                 //向server写入信息
//                                 socketChannel.write(writeBytes);
//                                 writeBytes.clear();
                                 //socketChannel.close();
                             } else if (selectionKey.isReadable()) {
                                 ByteBuffer buffer = ByteBuffer.allocate(1024);
                                 socketChannel.read(buffer);
                                 buffer.flip();
                                 System.out.println("server："+new String(buffer.array()).trim());
                                 
                                 
                                 //休眠一秒继续发送消息
                                 Thread.sleep(1000);
                                 
                                 
                                 //sc = SocketChannel.open();
                                 //继续向selector注册read事件
//                                 socketChannel.register(client.selector, SelectionKey.OP_READ);
//                                 writeBytes.put(writeSomething());
//                                 writeBytes.flip();
//                                 //向server写入信息
//                                 socketChannel.write(writeBytes);
//                                 writeBytes.clear();
                                 //sc.connect(address);
                             }
                             
                             //继续向selector注册read事件
                             socketChannel.register(client.selector, SelectionKey.OP_READ);
                             byte[] ws=writeSomething();
                             writeBytes.put(ws);
                             writeBytes.flip();
                             //向server写入信息
                             socketChannel.write(writeBytes);
                             writeBytes.clear();
            			}
            	}
            }
        }catch(IOException e){
            e.printStackTrace();
        } catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
            if(sc!=null){
                try {
                    sc.close();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        }
    }
	
	public static byte[] writeSomething() throws IOException{
		DateTimeFormatter format= DateTimeFormatter.ofPattern("yyyy-mm-dd HH:mm:ss");
		String time=format.format(LocalDateTime.now())+"-> ";
		System.out.print("请输入：");
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
        return (time+str).getBytes();
	}
	
	
}
