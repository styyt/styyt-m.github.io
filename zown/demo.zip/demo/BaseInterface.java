package com.sf.hos.assistant.demo;

public interface BaseInterface {
	public void doS();
}
