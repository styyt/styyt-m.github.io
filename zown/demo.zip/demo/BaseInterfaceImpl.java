package com.sf.hos.assistant.demo;

public class BaseInterfaceImpl implements BaseInterface {

	@Override
	public void doS() {
		// TODO Auto-generated method stub
		System.err.println("哈哈哈哈或或或或");
	}

}
