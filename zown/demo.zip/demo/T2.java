package com.sf.hos.assistant.demo;
public class 	T2 {
    public static void main(String[] args) {
            MyThread12 thread = new MyThread12();
            thread.start();
            
            thread.interrupt();
            System.out.println("是否终止1？ =" + thread.interrupted());
            System.out.println("是否终止2？ =" + thread.interrupted());
        System.out.println("-------------end-------------");
    }
}

class MyThread12 extends Thread {
    public void run() {
    		int j=0;
        for (int i = 0; i < Integer.MAX_VALUE; i++) {
        	j++;
        	if(j==500){
        		try {
					this.sleep(1000);
				} catch (InterruptedException e) {
					System.out.println("是否终止1？ =" + this.interrupted());
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        	}
            //System.out.println("i = " + i);
        }
    }
}