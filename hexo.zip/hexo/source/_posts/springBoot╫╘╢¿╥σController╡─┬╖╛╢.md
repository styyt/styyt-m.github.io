---
title: springBoot自定义Controller的路径
date: 2019-08-28 20:34:16
tags: springBoot
categories: springBoot
---

今天手工重新搭建springboot的时候发现一个以前遗漏的知识点：

**Spring Boot 官方默认扫描的包需要和启动类同级**，这里就间接体现了springboot约定大于配置的做法，如果我们需要自定义springboot的扫描路径，需要在启动类上加入如下注解：

```java
@ComponentScan(basePackages = {"项目路径"})
```

和spring很像哦~

