---
title: mybatis字符串比较
date: 2019-06-24 20:51:20
tags:
- mybatis
- 字符串比较
categories: mybatis
---

在mybatis的mapping内进行字符串比较应该使用以下方法:

`<if test='type=="y"'>  
    and status = 1   
</if>  `

或者

`<if test="type == 'y'.toString()">  
    and status = 1   
</if> `



不能使用这种写法`<if test="type == 'y'">  `，因为tset内是ognl表达式，'Y'在java内被认为是char类型，拿它和字符串比较肯定是为false

详细原理可参见：http://blog.csdn.net/z69183787/article/details/51589171