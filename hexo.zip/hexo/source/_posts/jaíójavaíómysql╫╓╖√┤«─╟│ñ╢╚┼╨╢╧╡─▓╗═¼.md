---
title: js、java、mysql字符串那长度判断的不同
date: 2017-06-15 20:16:29
tags:
- js
- java
- mysql
---

在项目中遇到这样一个问题：明明在js端做了长度控制，存储到后台还是报 data too long的数据库错误，经过排查，发现js、java、mysql中：js对文本框的回车即当做长度为1，而传到java、mysql中被处理为：‘\r\n’，存储认作2个单位，见下图：

![js](/intro/0016.png)

![java](/intro/0017.png)

![mysql](/intro/0018.png)

所以说日常中所有用户输入的重要校验都应该放在后端来进行再次校验，JS不能信呀~~~

