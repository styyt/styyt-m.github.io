---
title: tomcat,jetty,jboss跨域配置
date: 2019-08-02 22:14:51
tags:
- jetty
- jboss
- tomcat
- CORS
- spring
- sringboot
categories: CORS跨域
---

目前前后端分离的开发方式都是需要前端应用跨域访问后端服务器。这里记录下平时开发中用到的三种服务器支持跨域的方式。浏览器支持跨域的方式后面再讲。

先来了解下跨域的主流方式：

CORS：全称"跨域资源共享"（Cross-origin resource sharing）。

CORS需要浏览器和服务器同时支持，才可以实现跨域请求，目前几乎所有浏览器都支持CORS，IE则不能低于IE10。

## 一：springMVC版本低于4.2的war包部署至jboss、jetty、tomcat

在web.xml内加入处理跨域的过滤器（需要先引入jar包）：

```xml
<filter>
		<filter-name>cross-origin</filter-name>
		<filter-class>org.eclipse.jetty.servlets.CrossOriginFilter</filter-class>
		<init-param>
			<param-name>allowedOrigins</param-name>
			<param-value>*</param-value>
		</init-param>
		<init-param>
			<param-name>allowedMethods</param-name>
			<param-value>GET,POST,HEAD</param-value>
		</init-param>
		<init-param>
			<param-name>allowedHeaders</param-name>
			<param-value>X-Requested-With,Content-Type,Accept,Origin</param-value>
		</init-param>
	</filter>
	<!-- 此处标识服务中的所有url都可以支持跨域 -->
	<filter-mapping>
		<filter-name>cross-origin</filter-name>
		<url-pattern>/*</url-pattern>
	</filter-mapping>
```

## 二、springMVC版本大于4.2 or sptingBoot

方法一：一个@CrossOrigin就可以搞定。将@CrossOrigin加到Controller类或者其下的某个方法上，那么这个Controller所有的请求都是支持跨域的，代码如下：

```java
@Controller
@CrossOrigin
public class testC {}


@CrossOrigin(origins = "http://domain2.com", maxAge = 3600)
@RequestMapping("/test")
public @ResponseBody Test testC(@RequestParam(required=false, defaultValue="World") String name) {}
```

方法二：新增一个configration类 或 在Application中加入CorsFilter和CorsConfiguration方法

```java
import org.springframework.context.annotation.Bean;  
import org.springframework.context.annotation.Configuration;  
import org.springframework.web.cors.CorsConfiguration;  
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;  
import org.springframework.web.filter.CorsFilter;  
  
@Configuration  
public class CorsConfig {  
    private CorsConfiguration buildConfig() {  
        CorsConfiguration corsConfiguration = new CorsConfiguration();  
        corsConfiguration.addAllowedOrigin("*"); // 1允许任何域名使用
        corsConfiguration.addAllowedHeader("*"); // 2允许任何头
        corsConfiguration.addAllowedMethod("*"); // 3允许任何方法（post、get等） 
        return corsConfiguration;  
    }  
  
    @Bean  
    public CorsFilter corsFilter() {  
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();  
        source.registerCorsConfiguration("/**", buildConfig()); // 4  
        return new CorsFilter(source);  
    }  
}  
```

方法三：使用Filter方式

```java
import javax.servlet.*;  
import javax.servlet.http.HttpServletResponse;  
import java.io.IOException;  
   
@Component  
public class CorsFilter implements Filter {  
  
    final static org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(CorsFilter.class);  
 
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {  
        HttpServletResponse response = (HttpServletResponse) res;  
        response.setHeader("Access-Control-Allow-Origin", "*");  
        response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");  
        response.setHeader("Access-Control-Max-Age", "3600");  
        response.setHeader("Access-Control-Allow-Headers", "x-requested-with");
        chain.doFilter(req, res);  
    }  
    public void init(FilterConfig filterConfig) {}  
    public void destroy() {}  
} 
```

