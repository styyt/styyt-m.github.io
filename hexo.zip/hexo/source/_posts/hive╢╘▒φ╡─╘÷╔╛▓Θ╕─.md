---
title: hive对表的增删改
date: 2019-08-27 14:29:26
tags: hive
categories : hive
---

Hive 是针对数据仓库应用设计的，而数据仓库的内容是读多写少的。因此，Hive大部分情况下是不支持对数据的改写和添加，日常开发中如果需要真的对数据进行增删改，都可以通过模仿以下方式简单实现

- 增

1、文件方式增加：

```sql
#OVERWRITE 表示覆盖，不写则是append
LOAD DATA INPATH '/user/upload/3.csv' [OVERWRITE] INTO TABLE ods_sap_hr.bic_a100 PARTITION (inc_month=201907);
```

2、insert into 方式

```sql
#OVERWRITE 表示覆盖，不写则是append
insert into test(name,pwd,createdate)values('name2','pwd2','2017-06-20 14:14:09');
```

- 改

```sql
#OVERWRITE 表示覆盖，覆盖后就相当于更新了
insert overwrite table TMP_A partition (p='one') select id,"ddd" from A where id = 2;
```

- 删

和改同理

```sql
#OVERWRITE 表示覆盖，用空数据覆盖则就是变相删除
insert overwrite table TMP_A partition (p='one') select id,"ddd" from A where 1=2;
```

