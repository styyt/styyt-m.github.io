---
title: ajax的traditional作用
date: 2016-09-26 17:27:23
tags: ajax
categories: ajax
---

开发中前端利用ajax传递一个js数组对象，后台（struts）只能获取到数组的第一个值，后续值完全获取不到，经过查找资料，发现了解决方案

```javascript
$.ajax{
      url:"xxxx",
      traditional: true//这个设置为true，data:{"steps":["qwe","asd","zxc"]}会转换成steps=qwe&steps=asd&...
});
      data:{"steps":["qwe","asd","zxc"]}
}
```

这是因为jQuery封装参数时需要调用jQuery.param序列化参数，jQuery.param(obj, traditional )默认情况下traditional为false，即jquery会深度序列化参数对象，以适应如PHP和Ruby on Rails框架，但servelt api无法处理，我们需要通过设置traditional 为true阻止深度序列化，让servelt的框架可以有效识别参数是数组类型。

