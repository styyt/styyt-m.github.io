#!/bin/zsh
ttab -d ../../ hexo s
npm run dev
