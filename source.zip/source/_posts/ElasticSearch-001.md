---
title: ElasticSearch笔记
date: 2019-07-24
tags: 
- ElasticSearch
- Oracle
categories: ElasticSearch
---

最近开发的人员搜索功能使用到了ElasticSearch(ES)，所以把自己学到的东西记录下来

## 介绍

ES是一个分布式可扩展的实时搜索和分析引擎,一个建立在全文搜索引擎 Apache Lucene(TM) 基础上的搜索引擎.当然 ES并不仅仅是 Lucene 那么简单，它不仅包括了全文搜索功能，还可以进行以下工作:

- 分布式实时文件存储，并将每一个字段都编入索引，使其可以被搜索。

- 实时分析的分布式搜索引擎。

- 可以扩展到上百台服务器，处理PB级别的结构化或非结构化数据。

  经过两三天时间的琢磨，大概明白了ES的表面运作流程，ES除了上述特征之外，他提供服务的方式是RESTful web接口，开发人员通过RESTful标准的json请求对大数据进行操作和检索。

  简单来说就是可以提供RESTful web接口的非关系型数据库。他与传统关系型数据库比如oracle的对比大致如下：

  orecle：DB -> Databases -> Tables -> Rows -> Columns 

  ES： ES -> Indices -> Types -> Documents -> Fields

  

## ES搭配ETL、oracle、hive实现大数据全文检索

所需工具：hive，etl，oracle/mysql等

- 配置好etl的hive数据源和oracle数据源
- 创建hive中间表，比如：

```sql
create table if not EXISTS dm_hrmis.tm_hrmis_external_rel(emp_code string,rel_txt string,create_by string,create_time date,update_by string,update_time date)
row format delimited
fields terminated by ','
collection items terminated by '-'
map keys terminated by ':'
;
```

- 通过etl工具配置好抽数规则，定时从oracle/mysql抽取到hive，可以选择按照更新时间来分区，既方便又能做到数据备份

  ![2](/intro/0002.png)

- 通过etl将hive表的相关字段同步至ES的索引内

以上流程配置好后，就可以对ES的索引进行查询了。

简单查询示例如下：

`	curl -XGET http://localhost:9200/index01/_search -d {'query':{'term':{'title':'你好'}}}`

更详细使用方法可以参考网上的API