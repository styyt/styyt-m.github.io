---
title: hive存储换行符等特殊字符
date: 2019-08-06 11:14:24
tags: hive
categories: hive
---

etl抽取oracle数据到hive库中的时候，oracle表中如果有换行符如:‘\n\r’，会造成当前行的数据错位。

原来是因为hive默认的存储方式是textfile，这种方式不支持存储换行符。

方案一、替换这些特殊字符：

```sql
regexp_replace(t.test, '\n|\t|\r', '')
```

方案二、修改表的存储格式为:parquet

```sql
drop table if exists test_table;
create table test_table(
	create_by string comment '',
	create_time date comment '',
	update_by string comment '',
	update_time date comment ''
)
comment 'test_table'
partitioned by(inc_day string)
stored as parquet;
```

