---
title: hive从csv导入数据
date: 2019-08-15 20:35:23
tags: hive
categories: hive
---

今天开发hive数据迁移遇到个问题，从旧库导出来的csv文件死活导入不进新表中，导入语句如下：

```sql
LOAD DATA INPATH '/user/upload/xiaomifengceshi.csv' OVERWRITE INTO TABLE default.dm_fity PARTITION (inc_day=20190814);
```

后来研究发现：原来是导出的时候所选择的csv分隔符为’,‘（如下图:）

![11](/intro/0011.png)

![12](/intro/0012.png)

，但是新建的hive表的默认分割符，hive使用不可见的字符作为分割符，如下表

| 分隔符 | 描述                                                    |
| ------ | ------------------------------------------------------- |
| \n     | 行分隔符                                                |
| ^A     | 字段分隔符,八进制表示为\001,                            |
| ^B     | array或struct中为元素分隔符，map中为key-value分隔符\002 |
| ^C     | map中为key和value间的分隔符\003                         |

那么如果我们建表是没有使用以下语句，导入程序是肯定识别不出来上图中的正确数据的，所以大家还是要注意，保证导出hive数据和新建表格式的一致性

```sql
row format delimited fields terminated by ','
```

