---
title: ORA-01722 invalid number
date: 2019-07-13 18:38:05
tags: ORACLE
categories: ORACLE
permalink: ORA-01722 invalid number
---

 ORA-01722: invalid number最常见的原因就是因为我们在条件筛选时写了文本格式的（varchar2）字段与数字进行对比，Oracle的字段类型隐式转换调用了to_number函数，当字段内有非数字的值时，就会报这个错误。比如下面两个sql:	

```sql
select * from TM_hrmis_USER U WHERE  U.EMP_CODE=592876 
```

```sql
select * from TM_hrmis_USER U WHERE  U.EMP_CODE=592876 and u.emp_name='592876'
```

​		首先emp_code这个字段里有非数字的工号，所以第一句肯定会报ORA-01722，但是第二个sql，因为多加了条件，emp_name条件筛选出来的结果集的工号全是数字，所以不会报ORA-01722。

​		现在分析下第二个sql，在两个字段都有索引情况下，为什么oracle会自动筛选第二个条件而忽略第一个条件，我认为是因为第一个条件Oracle的隐式转换调用了to_number函数，所以不走emp_code的索引，而emp_name能直接走索引，所以会出现这种情况~根据执行计划即可看出我的猜想是对的：

![1](/intro/0001.png)

所以我们日常写sql还是要养成好习惯：筛选条件时使用相同类型进行判断。